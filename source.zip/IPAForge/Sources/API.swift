import Foundation

struct User: Decodable { let login: String }

struct Repo: Codable, Identifiable, Hashable {
    struct Owner: Codable, Hashable { let login: String }
    let id: Int
    let name: String
    let full_name: String
    let `private`: Bool
    let default_branch: String
    let owner: Owner
}

struct Asset: Codable, Identifiable, Hashable {
    let id: Int
    let name: String
    let size: Int
    let url: String
}

struct Release: Codable, Identifiable {
    let id: Int
    let name: String?
    let tag_name: String
    let assets: [Asset]
}

struct Run: Codable {
    let id: Int
    let status: String
    let conclusion: String?
    let html_url: String
}

private struct Runs: Codable { let workflow_runs: [Run] }
private struct Content: Codable { let sha: String }

enum APIError: LocalizedError {
    case http(Int, String)
    var errorDescription: String? {
        switch self {
        case let .http(code, msg): return "GitHub \(code) : \(msg)"
        }
    }
}

struct GitHubAPI {
    let token: String

    private func request(_ method: String, _ url: URL, _ body: [String: Any]? = nil) throws -> URLRequest {
        var r = URLRequest(url: url)
        r.httpMethod = method
        r.timeoutInterval = 600
        r.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        r.setValue("application/vnd.github+json", forHTTPHeaderField: "Accept")
        r.setValue("2022-11-28", forHTTPHeaderField: "X-GitHub-Api-Version")
        if let body {
            r.httpBody = try JSONSerialization.data(withJSONObject: body)
            r.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        return r
    }

    private func check(_ data: Data, _ resp: URLResponse) throws {
        let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
        guard (200..<300).contains(code) else {
            let msg = ((try? JSONSerialization.jsonObject(with: data)) as? [String: Any])?["message"] as? String
            throw APIError.http(code, msg ?? "erreur")
        }
    }

    @discardableResult
    private func send(_ method: String, _ path: String, _ body: [String: Any]? = nil) async throws -> Data {
        let (d, r) = try await URLSession.shared.data(for: request(method, URL(string: "https://api.github.com" + path)!, body))
        try check(d, r)
        return d
    }

    private func get<T: Decodable>(_ path: String) async throws -> T {
        try JSONDecoder().decode(T.self, from: await send("GET", path))
    }

    func user() async throws -> User { try await get("/user") }

    func repos() async throws -> [Repo] {
        try await get("/user/repos?per_page=100&sort=updated&affiliation=owner,collaborator")
    }

    func createRepo(name: String, isPrivate: Bool) async throws -> Repo {
        let d = try await send("POST", "/user/repos", ["name": name, "private": isPrivate, "auto_init": true])
        return try JSONDecoder().decode(Repo.self, from: d)
    }

    func putFile(_ repo: Repo, path: String, data: Data, message: String) async throws {
        let p = "/repos/\(repo.full_name)/contents/\(path)"
        let existing: Content? = try? await get("\(p)?ref=\(repo.default_branch)")
        var body: [String: Any] = [
            "message": message,
            "content": data.base64EncodedString(),
            "branch": repo.default_branch
        ]
        if let sha = existing?.sha { body["sha"] = sha }
        try await send("PUT", p, body)
    }

    func latestRun(_ repo: Repo) async throws -> Run? {
        let r: Runs = try await get("/repos/\(repo.full_name)/actions/runs?per_page=1")
        return r.workflow_runs.first
    }

    func releases(_ repo: Repo) async throws -> [Release] {
        try await get("/repos/\(repo.full_name)/releases?per_page=30")
    }

    func download(_ asset: Asset) async throws -> URL {
        var r = try request("GET", URL(string: asset.url)!)
        r.setValue("application/octet-stream", forHTTPHeaderField: "Accept")
        let (tmp, resp) = try await URLSession.shared.download(for: r)
        let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
        guard (200..<300).contains(code) else { throw APIError.http(code, "téléchargement impossible") }
        let dest = FileManager.default.temporaryDirectory.appendingPathComponent(asset.name)
        try? FileManager.default.removeItem(at: dest)
        try FileManager.default.moveItem(at: tmp, to: dest)
        return dest
    }
}

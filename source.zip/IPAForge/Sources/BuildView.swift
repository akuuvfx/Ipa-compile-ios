import SwiftUI
import UniformTypeIdentifiers

struct BuildView: View {
    enum Mode: String, CaseIterable { case new = "Nouveau dépôt", existing = "Dépôt existant" }

    @EnvironmentObject var auth: Auth
    @State private var mode: Mode = .new
    @State private var newName = ""
    @State private var isPrivate = true
    @State private var repos: [Repo] = []
    @State private var selected: Repo?
    @State private var zipName: String?
    @State private var zipData: Data?
    @State private var picking = false
    @State private var busy = false
    @State private var status = ""
    @State private var run: Run?
    @State private var error: String?

    private var canGo: Bool {
        zipData != nil && !busy &&
        (mode == .new ? !newName.trimmingCharacters(in: .whitespaces).isEmpty : selected != nil)
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    card("1 · Ton projet", "doc.zipper") {
                        Button { picking = true } label: {
                            Label(zipName ?? "Choisir un fichier .zip",
                                  systemImage: zipName == nil ? "square.and.arrow.down" : "checkmark.circle.fill")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.glass)
                        .controlSize(.large)
                    }

                    card("2 · Dépôt GitHub", "externaldrive.connected.to.line.below") {
                        Picker("", selection: $mode) {
                            ForEach(Mode.allCases, id: \.self) { Text($0.rawValue).tag($0) }
                        }
                        .pickerStyle(.segmented)

                        if mode == .new {
                            TextField("nom-du-depot", text: $newName)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                                .padding(12)
                                .glassEffect(.regular, in: .rect(cornerRadius: 14))
                            Toggle("Dépôt privé", isOn: $isPrivate)
                        } else {
                            Picker("Dépôt", selection: $selected) {
                                Text("Choisir…").tag(Repo?.none)
                                ForEach(repos) { Text($0.full_name).tag(Repo?.some($0)) }
                            }
                            .pickerStyle(.menu)
                        }
                    }

                    card("3 · Compiler", "hammer.fill") {
                        Button { Task { await go() } } label: {
                            Label("Envoyer et compiler", systemImage: "play.fill")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.glassProminent)
                        .controlSize(.large)
                        .disabled(!canGo)

                        if busy { ProgressView() }
                        if !status.isEmpty { Text(status).font(.subheadline) }
                        if let run, let u = URL(string: run.html_url) {
                            Link("Voir le build sur GitHub", destination: u).font(.footnote)
                        }
                        if let error { Text(error).font(.footnote).foregroundStyle(.red) }
                    }
                }
                .padding()
            }
            .navigationTitle("Compiler")
            .toolbar { ToolbarItem(placement: .topBarTrailing) { AccountMenu() } }
            .fileImporter(isPresented: $picking, allowedContentTypes: [.zip]) { res in
                guard case .success(let u) = res else { return }
                let ok = u.startAccessingSecurityScopedResource()
                defer { if ok { u.stopAccessingSecurityScopedResource() } }
                zipData = try? Data(contentsOf: u)
                zipName = u.lastPathComponent
            }
            .task { repos = (try? await auth.api?.repos()) ?? [] }
        }
    }

    private func card<C: View>(_ title: String, _ icon: String, @ViewBuilder _ content: () -> C) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Label(title, systemImage: icon).font(.headline)
            content()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18)
        .glassEffect(.regular, in: .rect(cornerRadius: 26))
    }

    private func go() async {
        guard let api = auth.api, let data = zipData else { return }
        busy = true; error = nil; run = nil
        defer { busy = false }
        do {
            let repo: Repo
            if mode == .new {
                status = "Création du dépôt…"
                let name = newName.trimmingCharacters(in: .whitespaces).replacingOccurrences(of: " ", with: "-")
                repo = try await api.createRepo(name: name, isPrivate: isPrivate)
                try await Task.sleep(for: .seconds(2))
            } else {
                guard let s = selected else { return }
                repo = s
            }
            status = "Ajout du workflow de compilation…"
            try await api.putFile(repo, path: ".github/workflows/build-ipa.yml",
                                  data: Data(workflowYAML.utf8), message: "Ajout du workflow IPA")
            let before = (try? await api.latestRun(repo))?.id
            status = "Envoi du ZIP…"
            try await api.putFile(repo, path: "source.zip", data: data, message: "Mise à jour de source.zip")
            status = "Compilation en cours…"
            for _ in 0..<360 {
                try await Task.sleep(for: .seconds(5))
                if let r = try await api.latestRun(repo), r.id != before {
                    run = r
                    if r.status == "completed" { break }
                }
            }
            if let r = run {
                status = r.conclusion == "success" ? "IPA prête ✅ — va dans l'onglet Télécharger" : "Échec de la compilation ❌"
            } else {
                status = "Aucun build détecté"
            }
        } catch {
            self.error = error.localizedDescription
            status = ""
        }
    }
}

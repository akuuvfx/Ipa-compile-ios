import SwiftUI

@main
struct IPAForgeApp: App {
    @StateObject private var auth = Auth()

    var body: some Scene {
        WindowGroup {
            Group {
                if auth.token == nil { LoginView() } else { RootTabs() }
            }
            .environmentObject(auth)
        }
    }
}

struct RootTabs: View {
    @EnvironmentObject var auth: Auth

    var body: some View {
        TabView {
            Tab("Compiler", systemImage: "hammer.fill") { BuildView() }
            Tab("Télécharger", systemImage: "arrow.down.circle.fill") { DownloadsView() }
        }
        .task { await auth.refreshUser() }
    }
}

struct AccountMenu: View {
    @EnvironmentObject var auth: Auth

    var body: some View {
        Menu {
            Text(auth.login.isEmpty ? "GitHub" : "@\(auth.login)")
            Button("Se déconnecter", role: .destructive) { auth.logout() }
        } label: {
            Image(systemName: "person.crop.circle")
        }
    }
}

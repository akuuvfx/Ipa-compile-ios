import SwiftUI

struct DownloadsView: View {
    @EnvironmentObject var auth: Auth
    @State private var repos: [Repo] = []
    @State private var search = ""
    @State private var loading = true
    @State private var error: String?

    private var filtered: [Repo] {
        search.isEmpty ? repos : repos.filter { $0.full_name.localizedCaseInsensitiveContains(search) }
    }

    var body: some View {
        NavigationStack {
            List(filtered) { repo in
                NavigationLink(value: repo) {
                    HStack {
                        Image(systemName: repo.private ? "lock.fill" : "shippingbox")
                            .foregroundStyle(.tint)
                        VStack(alignment: .leading) {
                            Text(repo.name).font(.headline)
                            Text(repo.owner.login).font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .overlay {
                if loading { ProgressView() }
                else if let error { ContentUnavailableView("Erreur", systemImage: "exclamationmark.triangle", description: Text(error)) }
            }
            .navigationTitle("Télécharger")
            .navigationDestination(for: Repo.self) { ReleasesView(repo: $0) }
            .searchable(text: $search, prompt: "Rechercher un dépôt")
            .toolbar { ToolbarItem(placement: .topBarTrailing) { AccountMenu() } }
            .refreshable { await load() }
            .task { await load() }
        }
    }

    private func load() async {
        do { repos = try await auth.api?.repos() ?? []; error = nil }
        catch { self.error = error.localizedDescription }
        loading = false
    }
}

struct ReleasesView: View {
    @EnvironmentObject var auth: Auth
    let repo: Repo
    @State private var releases: [Release] = []
    @State private var loading = true
    @State private var files: [Int: URL] = [:]
    @State private var downloading: Int?
    @State private var error: String?

    private var shown: [Release] { releases.filter { !$0.assets.isEmpty } }

    var body: some View {
        List {
            ForEach(shown) { rel in
                Section(rel.name ?? rel.tag_name) {
                    ForEach(rel.assets) { row($0) }
                }
            }
            if let error { Text(error).foregroundStyle(.red).font(.footnote) }
        }
        .overlay {
            if loading { ProgressView() }
            else if shown.isEmpty {
                ContentUnavailableView("Aucune IPA", systemImage: "shippingbox",
                                       description: Text("Compile d'abord ce dépôt depuis l'onglet Compiler."))
            }
        }
        .navigationTitle(repo.name)
        .navigationBarTitleDisplayMode(.inline)
        .task {
            do { releases = try await auth.api?.releases(repo) ?? [] }
            catch { self.error = error.localizedDescription }
            loading = false
        }
    }

    @ViewBuilder
    private func row(_ a: Asset) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text(a.name).font(.subheadline).lineLimit(2)
                Text(ByteCountFormatter.string(fromByteCount: Int64(a.size), countStyle: .file))
                    .font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            if let url = files[a.id] {
                ShareLink(item: url) { Image(systemName: "square.and.arrow.up") }
                    .buttonStyle(.glassProminent)
            } else if downloading == a.id {
                ProgressView()
            } else {
                Button { Task { await fetch(a) } } label: { Image(systemName: "arrow.down") }
                    .buttonStyle(.glass)
            }
        }
    }

    private func fetch(_ a: Asset) async {
        guard let api = auth.api else { return }
        downloading = a.id; error = nil
        defer { downloading = nil }
        do { files[a.id] = try await api.download(a) }
        catch { self.error = error.localizedDescription }
    }
}

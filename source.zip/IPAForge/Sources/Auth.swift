import SwiftUI
import Security

enum Keychain {
    private static var base: [String: Any] {
        [kSecClass as String: kSecClassGenericPassword, kSecAttrAccount as String: "github-token"]
    }
    static func set(_ value: String?) {
        SecItemDelete(base as CFDictionary)
        guard let value else { return }
        var q = base
        q[kSecValueData as String] = Data(value.utf8)
        SecItemAdd(q as CFDictionary, nil)
    }
    static func get() -> String? {
        var q = base
        q[kSecReturnData as String] = true
        q[kSecMatchLimit as String] = kSecMatchLimitOne
        var out: AnyObject?
        guard SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess,
              let d = out as? Data else { return nil }
        return String(data: d, encoding: .utf8)
    }
}

struct DeviceCode: Decodable {
    let deviceCode: String
    let userCode: String
    let verificationUri: String
    let interval: Int
    let expiresIn: Int
}

struct TokenReply: Decodable {
    let accessToken: String?
    let error: String?
}

@MainActor
final class Auth: ObservableObject {
    /// Client ID d'une OAuth App GitHub avec "Enable Device Flow" coché.
    static let clientID = "COLLE_TON_CLIENT_ID_ICI"

    @Published var token: String? = Keychain.get()
    @Published var device: DeviceCode?
    @Published var error: String?
    @Published var login = ""

    var api: GitHubAPI? { token.map { GitHubAPI(token: $0) } }

    func setToken(_ t: String?) { token = t; Keychain.set(t) }

    func logout() { setToken(nil); login = ""; device = nil }

    func refreshUser() async {
        guard let api else { return }
        do { login = try await api.user().login }
        catch APIError.http(401, _) { logout() }
        catch {}
    }

    func loginWithToken(_ raw: String) async {
        error = nil
        let t = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        do {
            _ = try await GitHubAPI(token: t).user()
            setToken(t)
        } catch { self.error = error.localizedDescription }
    }

    func startDeviceFlow() async {
        error = nil
        guard !Self.clientID.hasPrefix("COLLE") else {
            error = "Client ID manquant : renseigne-le dans Auth.swift ou utilise un token."
            return
        }
        do {
            let dc: DeviceCode = try await form("https://github.com/login/device/code",
                                                ["client_id": Self.clientID, "scope": "repo workflow"])
            device = dc
            var interval = dc.interval
            let deadline = Date().addingTimeInterval(Double(dc.expiresIn))
            while Date() < deadline, device != nil {
                try await Task.sleep(for: .seconds(interval))
                let r: TokenReply = try await form("https://github.com/login/oauth/access_token", [
                    "client_id": Self.clientID,
                    "device_code": dc.deviceCode,
                    "grant_type": "urn:ietf:params:oauth:grant-type:device_code"
                ])
                if let t = r.accessToken { setToken(t); device = nil; return }
                if r.error == "slow_down" { interval += 5 }
                else if r.error != "authorization_pending" { throw APIError.http(400, r.error ?? "erreur") }
            }
            device = nil
        } catch {
            device = nil
            self.error = error.localizedDescription
        }
    }

    private func form<T: Decodable>(_ url: String, _ fields: [String: String]) async throws -> T {
        var r = URLRequest(url: URL(string: url)!)
        r.httpMethod = "POST"
        r.setValue("application/json", forHTTPHeaderField: "Accept")
        r.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        r.httpBody = fields
            .map { "\($0.key)=\($0.value.addingPercentEncoding(withAllowedCharacters: .alphanumerics) ?? "")" }
            .joined(separator: "&").data(using: .utf8)
        let (d, _) = try await URLSession.shared.data(for: r)
        let dec = JSONDecoder()
        dec.keyDecodingStrategy = .convertFromSnakeCase
        return try dec.decode(T.self, from: d)
    }
}

struct LoginView: View {
    @EnvironmentObject var auth: Auth
    @Environment(\.openURL) private var openURL
    @State private var pat = ""
    @State private var showToken = false

    var body: some View {
        ZStack {
            LinearGradient(colors: [.indigo, .purple, .blue], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            VStack(spacing: 22) {
                Spacer()
                Image(systemName: "shippingbox.fill")
                    .font(.system(size: 64))
                    .foregroundStyle(.white)
                Text("IPA Forge").font(.largeTitle.bold()).foregroundStyle(.white)
                Text("Envoie un ZIP, récupère ton IPA.")
                    .foregroundStyle(.white.opacity(0.85))
                Spacer()

                VStack(spacing: 14) {
                    if let d = auth.device {
                        Text(d.userCode)
                            .font(.system(size: 36, weight: .bold, design: .monospaced))
                        Text("Entre ce code sur GitHub pour autoriser l'app.")
                            .font(.footnote).multilineTextAlignment(.center)
                        Button {
                            UIPasteboard.general.string = d.userCode
                            if let u = URL(string: d.verificationUri) { openURL(u) }
                        } label: {
                            Label("Copier le code et ouvrir GitHub", systemImage: "arrow.up.forward.app")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.glassProminent)
                        ProgressView("En attente de validation…")
                    } else {
                        Button {
                            Task { await auth.startDeviceFlow() }
                        } label: {
                            Label("Se connecter avec GitHub", systemImage: "person.badge.key.fill")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.glassProminent)
                        .controlSize(.large)

                        DisclosureGroup("Utiliser un token d'accès", isExpanded: $showToken) {
                            SecureField("ghp_… (scopes repo + workflow)", text: $pat)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                                .padding(10)
                                .glassEffect(.regular, in: .rect(cornerRadius: 14))
                            Button("Valider le token") { Task { await auth.loginWithToken(pat) } }
                                .buttonStyle(.glass)
                                .disabled(pat.isEmpty)
                        }
                        .font(.footnote)
                    }
                    if let e = auth.error {
                        Text(e).font(.footnote).foregroundStyle(.red).multilineTextAlignment(.center)
                    }
                }
                .padding(20)
                .glassEffect(.regular, in: .rect(cornerRadius: 28))
                .padding(.horizontal)
                .padding(.bottom, 30)
            }
        }
    }
}
